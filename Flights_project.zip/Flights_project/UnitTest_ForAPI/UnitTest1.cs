﻿using System;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest_ForAPI
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
          HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(string.Format("http://localhost:56181/"));
          WebReq.Method = "GET";
          HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            

        }
    }
}
